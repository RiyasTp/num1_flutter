
class Game{
  static int tries = 0;
  static bool won = false;
  static bool inGame = true;
  static late String num1;
  
  Game(){
    var digits =  List.generate(10, (i) => i);
    digits.shuffle();
    num1 = digits.sublist(0, 3).join();
    print(num1);
  }

  checkWin (String input){
    Map positons ={'correct': 0, 'wrong': 0} ;
    if (tries < 5 && inGame) {
      positons = checkNum(input);
      if (won)  print("You won!!");
      tries++;
      if(tries>4){
        inGame = false;
      } 
    }
    if(tries==5 && !inGame) {
      print("You lose !! the number is $num1");
      tries++;
      return;
    }
    if(!inGame){
      print('play again'); 
    }
    return positons;
  }

    Map checkNum(String input){
    String num1 = Game.num1;
    int wrongPlace = 0;
    int correctPlace = 0;
    Map result= {'correct': correctPlace, 'wrong': wrongPlace};
    
    String inputNum = input;

    if (num1 == inputNum) {
      Game.won = true;
      Game.inGame = false;
      return result; 
    }
    for (var i = 0; i < 3; i++) {
      if (num1[i] == inputNum[i]) {
        correctPlace++;
        continue;
      }
      for (var j = 0; j < 3; j++) {
        if (num1[i] == inputNum[j]) wrongPlace++;
      }
    } 
    print(
        "$correctPlace numbers are correct and well placed \n"
        "$wrongPlace numbers are correct but wrongly placed \n");
    
     return {'correct': correctPlace, 'wrong': wrongPlace};

  }

}
