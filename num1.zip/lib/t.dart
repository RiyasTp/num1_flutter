import 'dart:io';

void main(List<String> args) {
  int tries = 0;
  bool won = false;

  var digits = new List.generate(10, (i) => i);
  digits.shuffle();

  String num1 = digits.sublist(0, 3).join();
  // print(n

  while (tries < 5) {
    int wrongPlace = 0;
    int correctPlace = 0;

    print("please enter a 3 DIGIT number\n");
    String input_num = stdin.readLineSync()!;

    if (num1 == input_num) {
      won = true;
      break;
    }
    for (var i = 0; i < 3; i++) {
      if (num1[i] == input_num[i]) {
        correctPlace++;
        continue;
      }
      for (var j = 0; j < 3; j++) {
        if (num1[i] == input_num[j]) wrongPlace++;
      }
    }

    print(
        "$correctPlace numbers are correct and well placed \n"
        "$wrongPlace numbers are correct but wrongly placed \n");
    tries++;
  }
  if (won)  print("You won!!");
     else print("You lose !! the number is $num1");
}