import 'dart:io';

void main(List<String> args) {
  int tries = 0;
  bool won = false;

  var digits =  List.generate(10, (i) => i);
  digits.shuffle();
  String num1 = digits.sublist(0, 3).join();


  while (tries < 5) {
    int wrongPlace = 0;
    int correctPlace = 0;

    print("please enter a 3 DIGIT number\n");
    String inputNum = stdin.readLineSync()!;

    if (num1 == inputNum) {
      won = true;
      break;
    }
    for (var i = 0; i < 3; i++) {
      if (num1[i] == inputNum[i]) {
        correctPlace++;
        continue;
      }
      for (var j = 0; j < 3; j++) {
        if (num1[i] == inputNum[j]) wrongPlace++;
      }
    }

    print(
        "$correctPlace numbers are correct and well placed \n"
        "$wrongPlace numbers are correct but wrongly placed \n");
    tries++;
  }
  if (won) {
    print("You won!!");
  } else {
    print("You lose !! the number is $num1");
  }
}



class Game{
  static int tries = 0;
  static bool won = false;
  static late String num1;
  
  Game(){
    var digits =  List.generate(10, (i) => i);
    digits.shuffle();
    num1 = digits.sublist(0, 3).join();
  }

  checkWin (InputNum inputNum){
    if (tries < 5) {
      inputNum.checkNum(num1);
      tries++;
      if (won)  print("You won!!");
    }
    else {
      print("You lose !! the number is $num1");
    }
  }

}

class InputNum {
   int n2= 0;
   int n1=0;
   int n3 =0 ;

  String getInputNum(){
    return '$n1$n2$n3';
  }

  checkNum(String gNum){
    String num1 = gNum;
    int wrongPlace = 0;
    int correctPlace = 0;

    
    String inputNum = getInputNum();

    if (num1 == inputNum) {
      Game.won = true;
      return;
    }
    for (var i = 0; i < 3; i++) {
      if (num1[i] == inputNum[i]) {
        correctPlace++;
        continue;
      }
      for (var j = 0; j < 3; j++) {
        if (num1[i] == inputNum[j]) wrongPlace++;
      }
    }

    print(
        "$correctPlace numbers are correct and well placed \n"
        "$wrongPlace numbers are correct but wrongly placed \n");
    
  }
  
}