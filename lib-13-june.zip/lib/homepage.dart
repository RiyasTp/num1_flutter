import 'package:flutter/material.dart';
import 'package:num1/logic.dart';
import 'num_scroll.dart';

import 'scorll_wheel_number.dart';

class HomePage extends StatelessWidget{
   HomePage({Key? key}) : super(key: key);

  ValueNotifier<List<String>> playedNumbers = ValueNotifier(['020','000','000','000','000']);  
  ValueNotifier<String> newNumber = ValueNotifier('000');
  Game newGame = Game();  

  void newInputNum(String newInputNum) {
    newNumber.value =newInputNum; 
    playedNumbers.value[Game.tries]=newInputNum;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 21, 0, 48),
      appBar: AppBar(
        title: const Text('Num1'),
      ),
      body: Column(
        children: [
          // ValueListenableBuilder(
          //       valueListenable: newNumber,
          //       builder: (BuildContext context,List newN,Widget? c) {
          //         return ListView.builder(
          //           itemCount: 1, 
          //           itemBuilder: (context, i){
          //             return NumberBlocks(newNumber: newN[i]);  
          //           });
          //       }
          //     ), 

          Expanded( 
              child: Column(
            children: [
                ValueListenableBuilder(
                valueListenable: playedNumbers,
                builder: (BuildContext context,List newN,Widget? c) {
                  return NumberBlocks(newNumber: newNumber.value);  
                }
              ),  
            ],
          )), 
           NumScroll(newNumber: newInputNum,),
          ElevatedButton(
            onPressed: () {
              print(playedNumbers.value);
              newGame.checkWin(playedNumbers.value[Game.tries]); 
            },
            child: const Text('Check'),
          ),
          const SizedBox(
            height: 50,
          )
        ],
      ),
    );
  }
}


class NumberBlocks extends StatelessWidget {
  String newNumber; 
   NumberBlocks({Key? key,required  this.newNumber}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
                padding: const EdgeInsets.all(10.0),
                child: Column(children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children:  [
                      ScrolWheelNumber(
                        number: newNumber[0],
                        selectedColor: Colors.amber,
                        fontSize: 50,
                      ),
                      const SizedBox(width: 10),
                       ScrolWheelNumber(
                        number: newNumber[1],
                        selectedColor: Colors.amber,
                        fontSize: 50,
                      ),
                      const SizedBox(width: 10),
                       ScrolWheelNumber(
                        number: newNumber[2],
                        selectedColor: Colors.amber,
                        fontSize: 50,
                      ),
                    ]
                  ),
                  const Text(
                    'numbers are correct and well placed \n numbers are correct but wrongly placed \n',
                    style: TextStyle(color: Colors.amber),
                    textAlign: TextAlign.center,
                  )
                ]),
              );
  }
}