import 'package:flutter/material.dart';

class ParentPage extends StatefulWidget {
  @override
  _ParentPageState createState() => _ParentPageState();
}

class _ParentPageState extends State<ParentPage> {
  int _count = 0;

  // Pass this method to the child page.
  void _update(int count) {
    setState(() => _count = count);
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Text('Value (in parent) = $_count'),
          ChildPage(update: _update),
        ],
      ),
    );
  }
}
class ChildPage extends StatefulWidget {
  final ValueChanged<int> update;
  ChildPage({required this.update});

  @override
  State<ChildPage> createState() => _ChildPageState();
}

class _ChildPageState extends State<ChildPage> {
  int c=50; 

  @override 
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: () {
        setState(() {
        c++;
           
        });
        print(c);
        widget.update(c+=1);

      } , // Passing value to the parent widget.
      child: const Text('Update (in child)'),
    );
  }
}